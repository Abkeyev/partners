self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2aa95cd2cdf3ba71d1bc883ce28b0464",
    "url": "/partners/index.html"
  },
  {
    "revision": "7983ec2f9209c603e15a",
    "url": "/partners/static/css/main.63196d51.chunk.css"
  },
  {
    "revision": "3372fffe6ac6f2fcad23",
    "url": "/partners/static/js/2.a6d8d555.chunk.js"
  },
  {
    "revision": "9652715b819d26dcc09aad3261a56a36",
    "url": "/partners/static/js/2.a6d8d555.chunk.js.LICENSE"
  },
  {
    "revision": "7983ec2f9209c603e15a",
    "url": "/partners/static/js/main.7aff7f70.chunk.js"
  },
  {
    "revision": "07bbe84c71633b336420",
    "url": "/partners/static/js/runtime-main.cf6c5b9a.js"
  }
]);